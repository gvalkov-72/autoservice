@extends('adminlte::page')

@section('title', 'Преглед на поръчка')

@section('content_header')
    <h1>Поръчка № {{ $workOrder->number }}</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <p><strong>Клиент:</strong> {{ $workOrder->customer->name }}</p>
                    <p><strong>Автомобил:</strong> {{ $workOrder->vehicle->plate ?? '-' }} - {{ $workOrder->vehicle->make }} {{ $workOrder->vehicle->model }}</p>
                    <p><strong>Статус:</strong> {{ $workOrder->status }}</p>
                </div>
                <div class="col-md-4">
                    <p><strong>Приета на:</strong> {{ $workOrder->received_at ? \Carbon\Carbon::parse($workOrder->received_at)->format('d.m.Y H:i') : '-' }}</p>
                    <p><strong>Пробег:</strong> {{ $workOrder->km_on_receive ?? '-' }} км</p>
                    <p><strong>Механик:</strong> {{ $workOrder->mechanic->name ?? '-' }}</p>
                </div>
                <div class="col-md-4">
                    <p><strong>Общо без ДДС:</strong> {{ number_format($workOrder->total_without_vat, 2) }} лв.</p>
                    <p><strong>ДДС:</strong> {{ number_format($workOrder->vat_amount, 2) }} лв.</p>
                    <p><strong>Общо:</strong> {{ number_format($workOrder->total, 2) }} лв.</p>
                </div>
            </div>
            <hr>
            <h4>Позиции</h4>
            <table class="table table-sm table-bordered">
                <thead>
                    <tr>
                        <th>№</th>
                        <th>Описание</th>
                        <th>Количество</th>
                        <th>Цена (без ДДС)</th>
                        <th>ДДС %</th>
                        <th>Общо</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($workOrder->items as $item)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $item->description }}</td>
                            <td>{{ $item->quantity }}</td>
                            <td>{{ number_format($item->unit_price, 2) }} лв.</td>
                            <td>{{ $item->vat_percent }} %</td>
                            <td>{{ number_format($item->line_total, 2) }} лв.</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <p><strong>Бележки:</strong></p>
            <p>{{ $workOrder->notes ?? '-' }}</p>
        </div>
        <div class="card-footer">
            <a href="{{ route('admin.work-orders.edit', $workOrder) }}" class="btn btn-primary">Редактирай</a>
            <a href="{{ route('admin.work-orders.index') }}" class="btn btn-secondary">Назад</a>
        </div>
    </div>
@stop