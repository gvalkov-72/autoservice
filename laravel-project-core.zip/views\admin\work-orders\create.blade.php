@extends('adminlte::page')

@section('title', 'Нова поръчка')

@section('content_header')
    <h1>Нова поръчка</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-body">
            <form action="{{ route('admin.work-orders.store') }}" method="POST" id="orderForm">
                @csrf
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Клиент</label>
                            <select name="customer_id" id="customer_id" class="form-control select2" required>
                                <option value="">Изберете клиент</option>
                                @foreach($customers as $id => $name)
                                    <option value="{{ $id }}">{{ $name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Автомобил</label>
                            <select name="vehicle_id" id="vehicle_id" class="form-control" required>
                                <option value="">Първо изберете клиент</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Механик</label>
                            <select name="assigned_to" class="form-control">
                                <option value="">Без механик</option>
                                @foreach($mechanics as $id => $name)
                                    <option value="{{ $id }}">{{ $name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Статус</label>
                            <select name="status" class="form-control" required>
                                <option value="draft">Чернова</option>
                                <option value="open">Отворена</option>
                                <option value="in_progress">В прогрес</option>
                                <option value="completed">Завършена</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Дата приемане</label>
                            <input type="datetime-local" name="received_at" class="form-control" value="{{ now()->format('Y-m-d\TH:i') }}">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Пробег при приемане</label>
                            <input type="number" name="km_on_receive" class="form-control" min="0">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label>Бележки</label>
                    <textarea name="notes" class="form-control" rows="3"></textarea>
                </div>

                {{-- Динамична таблица с позиции --}}
                <hr>
                <h4>Позиции</h4>
                <div class="table-responsive">
                    <table class="table table-sm table-bordered" id="itemsTable">
                        <thead>
                            <tr>
                                <th>№</th>
                                <th>Продукт (PLU)</th>
                                <th>Описание</th>
                                <th>Кол-во</th>
                                <th>Цена (без ДДС)</th>
                                <th>ДДС %</th>
                                <th>Общо</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                    <button type="button" id="addRow" class="btn btn-sm btn-outline-success">Добави ред</button>
                </div>

                <div class="row mt-3">
                    <div class="col-md-4 ml-auto">
                        <table class="table table-sm">
                            <tr>
                                <th>Общо без ДДС:</th>
                                <td><span id="totalWithoutVat">0.00</span> лв.</td>
                            </tr>
                            <tr>
                                <th>ДДС:</th>
                                <td><span id="totalVat">0.00</span> лв.</td>
                            </tr>
                            <tr>
                                <th>Общо:</th>
                                <td><span id="grandTotal">0.00</span> лв.</td>
                            </tr>
                        </table>
                    </div>
                </div>

                <button type="submit" class="btn btn-success">Създай поръчка</button>
                <a href="{{ route('admin.work-orders.index') }}" class="btn btn-secondary">Отказ</a>
            </form>
        </div>
    </div>
@stop

@push('css')
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
@endpush

@push('js')
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(function () {
            $('.select2').select2();

            $('#customer_id').change(function () {
                let customerId = $(this).val();
                $('#vehicle_id').html('<option value="">Зареждане...</option>');
                $.get("{{ url('admin/api/customer-vehicles') }}/" + customerId, function (data) {
                    let html = '<option value="">Изберете автомобил</option>';
                    $.each(data, function (i, v) {
                        html += '<option value="' + v.id + '">' + v.plate + ' - ' + v.make + ' ' + v.model + '</option>';
                    });
                    $('#vehicle_id').html(html);
                });
            });
        });

        let rowIdx = 0;

        function calcLine(row) {
            const qty  = parseFloat(row.find('.qty').val()) || 0;
            const price= parseFloat(row.find('.price').val()) || 0;
            const vat  = parseFloat(row.find('.vat').val()) || 0;
            const line = qty * price;
            const vatAm= line * vat / 100;
            row.find('.lineTotal').text((line + vatAm).toFixed(2));
            calcTotals();
        }

        function calcTotals() {
            let totalWithout = 0, totalVat = 0;
            $('#itemsTable tbody tr').each(function () {
                const qty   = parseFloat($(this).find('.qty').val()) || 0;
                const price = parseFloat($(this).find('.price').val()) || 0;
                const vat   = parseFloat($(this).find('.vat').val()) || 0;
                const line  = qty * price;
                totalWithout += line;
                totalVat     += line * vat / 100;
            });
            $('#totalWithoutVat').text(totalWithout.toFixed(2));
            $('#totalVat').text(totalVat.toFixed(2));
            $('#grandTotal').text((totalWithout + totalVat).toFixed(2));
        }

        $('#addRow').click(function () {
            rowIdx++;
            const html = `
                <tr id="R${rowIdx}">
                    <td>${rowIdx}</td>
                    <td><select name="items[${rowIdx}][product_id]" class="form-control product-select" style="width:100%">
                            <option value="">Изберете продукт</option>
                            @foreach(\App\Models\Product::select('id','sku','name','price','vat_percent')->get() as $p)
                                <option value="{{ $p->id }}" data-price="{{ $p->price }}" data-vat="{{ $p->vat_percent }}">{{ $p->sku }} - {{ $p->name }}</option>
                            @endforeach
                        </select></td>
                    <td><input type="text" name="items[${rowIdx}][description]" class="form-control" required></td>
                    <td><input type="number" name="items[${rowIdx}][quantity]" class="form-control qty" min="0.01" step="0.01" value="1" required></td>
                    <td><input type="number" name="items[${rowIdx}][unit_price]" class="form-control price" min="0.01" step="0.01" required></td>
                    <td><input type="number" name="items[${rowIdx}][vat_percent]" class="form-control vat" min="0" max="100" step="0.01" value="20" required></td>
                    <td class="lineTotal">0.00</td>
                    <td><button type="button" class="btn btn-sm btn-danger removeRow">×</button></td>
                </tr>`;
            $('#itemsTable tbody').append(html);
            $('.product-select').select2({theme: 'bootstrap4'});
        });

        $(document).on('click', '.removeRow', function () {
            $(this).closest('tr').remove();
            calcTotals();
        });

        $(document).on('change keyup', '.qty, .price, .vat', function () {
            calcLine($(this).closest('tr'));
        });

        $(document).on('change', '.product-select', function () {
            const option = $(this).find(':selected');
            const row    = $(this).closest('tr');
            row.find('.price').val(option.data('price'));
            row.find('.vat').val(option.data('vat'));
            calcLine(row);
        });
    </script>
@endpush