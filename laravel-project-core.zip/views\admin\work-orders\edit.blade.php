@extends('adminlte::page')

@section('title', 'Редактирай поръчка')

@section('content_header')
    <h1>Редактирай поръчка № {{ $workOrder->number }}</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-body">
            <form action="{{ route('admin.work-orders.update', $workOrder) }}" method="POST">
                @csrf @method('PUT')
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Клиент</label>
                            <select name="customer_id" id="customer_id" class="form-control select2" required>
                                @foreach($customers as $id => $name)
                                    <option value="{{ $id }}" {{ $workOrder->customer_id == $id ? 'selected' : '' }}>{{ $name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Автомобил</label>
                            <select name="vehicle_id" id="vehicle_id" class="form-control" required>
                                <option value="">Изберете автомобил</option>
                                @foreach($vehicles as $id => $plate)
                                    <option value="{{ $id }}" {{ $workOrder->vehicle_id == $id ? 'selected' : '' }}>{{ $plate }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Механик</label>
                            <select name="assigned_to" class="form-control">
                                <option value="">Без механик</option>
                                @foreach($mechanics as $id => $name)
                                    <option value="{{ $id }}" {{ $workOrder->assigned_to == $id ? 'selected' : '' }}>{{ $name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Статус</label>
                            <select name="status" class="form-control" required>
                                @foreach(['draft','open','in_progress','completed','invoiced','closed','cancelled'] as $s)
                                    <option value="{{ $s }}" {{ $workOrder->status == $s ? 'selected' : '' }}>{{ ucfirst($s) }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Дата приемане</label>
                            <input type="datetime-local" name="received_at" class="form-control" value="{{ old('received_at', $workOrder->received_at ? \Carbon\Carbon::parse($workOrder->received_at)->format('Y-m-d\TH:i') : '') }}">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Пробег при приемане</label>
                            <input type="number" name="km_on_receive" class="form-control" value="{{ old('km_on_receive', $workOrder->km_on_receive) }}" min="0">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label>Бележки</label>
                    <textarea name="notes" class="form-control" rows="3">{{ old('notes', $workOrder->notes) }}</textarea>
                </div>
                <button type="submit" class="btn btn-success">Запази</button>
                <a href="{{ route('admin.work-orders.index') }}" class="btn btn-secondary">Отказ</a>
            </form>
        </div>
    </div>
@stop