<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\User;
use App\Models\Vehicle;
use App\Models\WorkOrder;
use App\Models\WorkOrderItem;
use App\Models\StockMovement;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;   // <-- добавено

class WorkOrderController extends Controller
{
    public function index()
    {
        $workOrders = WorkOrder::with(['customer', 'vehicle', 'mechanic'])->paginate(25);
        return view('admin.work-orders.index', compact('workOrders'));
    }

    public function create()
    {
        $customers = Customer::pluck('name', 'id');
        $vehicles  = collect();
        $mechanics = User::role('mechanic')->pluck('name', 'id');
        return view('admin.work-orders.create', compact('customers', 'vehicles', 'mechanics'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'customer_id'   => 'required|exists:customers,id',
            'vehicle_id'    => 'nullable|exists:vehicles,id',
            'status'        => 'required|in:draft,open,in_progress,completed,invoiced,closed,cancelled',
            'received_at'   => 'nullable|date',
            'km_on_receive' => 'nullable|integer|min:0',
            'assigned_to'   => 'nullable|exists:users,id',
            'notes'         => 'nullable|string',
            'items'         => 'required|array|min:1',
            'items.*.description' => 'required|string',
            'items.*.quantity'    => 'required|numeric|min:0.01',
            'items.*.unit_price'  => 'required|numeric|min:0',
            'items.*.vat_percent' => 'required|numeric|min:0|max:100',
        ]);

        $order = DB::transaction(function () use ($validated, $request) {
            $userId = Auth::check() ? Auth::user()->id : 0;

            $order = WorkOrder::create([
                'number'        => 'WO-' . str_pad(WorkOrder::count() + 1, 6, '0', STR_PAD_LEFT),
                'customer_id'   => $validated['customer_id'],
                'vehicle_id'    => $validated['vehicle_id'] ?? null,
                'status'        => $validated['status'],
                'received_at'   => $validated['received_at'] ?? now(),
                'km_on_receive' => $validated['km_on_receive'],
                'assigned_to'   => $validated['assigned_to'],
                'notes'         => $validated['notes'],
                'created_by'    => $userId,
            ]);

            $totalWithout = 0;
            foreach ($request->items as $row) {
                $qty   = $row['quantity'];
                $price = $row['unit_price'];
                $vat   = $row['vat_percent'];
                $line  = $qty * $price;
                $vatAm = $line * $vat / 100;

                WorkOrderItem::create([
                    'work_order_id'           => $order->id,
                    'product_id'              => $row['product_id'] ?: null,
                    'description'             => $row['description'],
                    'quantity'                => $qty,
                    'unit_price'              => $price,
                    'vat_percent'             => $vat,
                    'line_total_without_vat'  => $line,
                    'line_vat_amount'         => $vatAm,
                    'line_total'              => $line + $vatAm,
                ]);

                $totalWithout += $line;

                if ($row['product_id']) {
                    StockMovement::create([
                        'product_id'     => $row['product_id'],
                        'change'         => -$qty,
                        'type'           => 'reservation',
                        'reference_id'   => $order->id,
                        'reference_type' => WorkOrder::class,
                        'created_by'     => $userId,
                    ]);
                }
            }

            $order->update([
                'total_without_vat' => $totalWithout,
                'vat_amount'        => $order->items()->sum('line_vat_amount'),
                'total'             => $order->items()->sum('line_total'),
            ]);

            return $order;
        });

        return redirect()->route('admin.work-orders.show', $order)->with('success', 'Поръчката е създадена.');
    }

    public function show(WorkOrder $workOrder)
    {
        $workOrder->load(['items.product', 'customer', 'vehicle', 'mechanic']);
        return view('admin.work-orders.show', compact('workOrder'));
    }

    public function edit(WorkOrder $workOrder)
    {
        $customers = Customer::pluck('name', 'id');
        $vehicles  = Vehicle::where('customer_id', $workOrder->customer_id)->pluck('plate', 'id');
        $mechanics = User::role('mechanic')->pluck('name', 'id');
        return view('admin.work-orders.edit', compact('workOrder', 'customers', 'vehicles', 'mechanics'));
    }

    public function update(Request $request, WorkOrder $workOrder)
    {
        $validated = $request->validate([
            'customer_id'   => 'required|exists:customers,id',
            'vehicle_id'    => 'nullable|exists:vehicles,id',
            'status'        => 'required|in:draft,open,in_progress,completed,invoiced,closed,cancelled',
            'received_at'   => 'nullable|date',
            'km_on_receive' => 'nullable|integer|min:0',
            'assigned_to'   => 'nullable|exists:users,id',
            'notes'         => 'nullable|string',
        ]);

        $workOrder->update($validated);

        return redirect()->route('admin.work-orders.index')->with('success', 'Поръчката е обновена.');
    }

    public function destroy(WorkOrder $workOrder)
    {
        $workOrder->items()->delete();
        $workOrder->delete();
        return redirect()->route('admin.work-orders.index')->with('success', 'Поръчката е изтрита.');
    }

    public function pdf(\App\Models\WorkOrder $workOrder, Request $request)
    {
        $invoice = $workOrder->invoices()->first();
        if (! $invoice) {
            $userId = Auth::check() ? Auth::user()->id : 0;

            $invoice = \App\Models\Invoice::create([
                'number'        => 'INV-' . str_pad(\App\Models\Invoice::count() + 1, 6, '0', STR_PAD_LEFT),
                'work_order_id' => $workOrder->id,
                'customer_id'   => $workOrder->customer_id,
                'issue_date'    => now(),
                'due_date'      => now()->addDays(14),
                'subtotal'      => $workOrder->total_without_vat,
                'vat_total'     => $workOrder->vat_amount,
                'grand_total'   => $workOrder->total,
                'status'        => 'draft',
                'created_by'    => $userId,
            ]);

            foreach ($workOrder->items as $item) {
                $invoice->items()->create([
                    'product_id'  => $item->product_id,
                    'description' => $item->description,
                    'quantity'    => $item->quantity,
                    'unit_price'  => $item->unit_price,
                    'vat_percent' => $item->vat_percent,
                    'line_total'  => $item->line_total,
                ]);
            }
        }

        $copy = $request->get('copy', 0);
        return Pdf::loadView('admin.invoices.pdf', compact('invoice', 'copy'))
                  ->stream('invoice_' . $invoice->number . '.pdf');
    }
}